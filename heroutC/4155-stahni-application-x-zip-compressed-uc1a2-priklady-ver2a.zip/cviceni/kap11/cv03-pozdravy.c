/*
 * cv03-pozdravy.c    v.2.0
 *
 * Pouziti pole pointeru na funkce - soubor funkci POZDRAVY
 * ========================================================
 *
 */

#include <stdio.h>

/* definice jednotlivych funkci */
void ahoj(void)
{
  printf("Ahoj\n");
}

void nazdar(void)
{
  printf("Nazdar\n");
}

void cau(void)
{
  printf("Cau\n");
}

void dobry_den(void)
{
  printf("Dobry den\n");
}

