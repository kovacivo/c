/*
 * cv03-pozdravy.h    v.2.0
 *
 * Pouziti pole pointeru na funkce - soubor funkcnich prototypu POZDRAVY
 * ======================================================================
 *
 */

void ahoj(void);
void nazdar(void);
void cau(void);
void dobry_den(void);
