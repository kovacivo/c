/*
 * cv11-hlavni.c    v.2.0
 *
 * Vypis libovolneho souboru - HLAVNI soubor
 * =========================================
 *
 */

int main(void)
{
   while (vypis_soubor() != 2.2)
     ;
  return 0;
}

