/*
 * cv16-a.c    v.2.0
 *
 * Promenna sdilena dvema soubory - definice
 * =========================================
 *
 * Pozor - nefunkcni, protoze static urcuje omezenou viditelnost
 */

/* definice promenne */
static int iii = 5;
