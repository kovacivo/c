/*
 * cv10-hlavni.c    v.2.0
 *
 * Vypis libovolneho souboru - HLAVNI soubor
 * =========================================
 *
 */

#include "cv10-fce.c"

int main(void)
{
   while (vypis_soubor() != 2.2)
     ;
  return 0;
}

