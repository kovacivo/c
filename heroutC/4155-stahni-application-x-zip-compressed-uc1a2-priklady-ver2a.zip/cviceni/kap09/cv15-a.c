/*
 * cv15-a.c    v.2.0
 *
 * Promenna sdilena dvema soubory - definice
 * =========================================
 *
 */

/* definice promenne */
int iii = 5;
