/*
 * cv14-fce.h    v.2.0
 *
 * Vypis libovolneho souboru - hlavickovy FCE soubor
 * =================================================
 *
 */

/* uplny funkcni prototyp */
double vypis_soubor(void);
