/*
 * cv16-b.c    v.2.0
 *
 * Promenna sdilena dvema soubory - pouziti
 * ========================================
 *
 */

#include <stdio.h>

/* deklarace promenne */
extern int iii;

int main(void)
{
  printf("Promenna 'iii' ma hodnotu %d\n", iii);
  return 0;
}

