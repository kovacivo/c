/*
 * cv14.c    v.2.0
 *
 * Zvukovy vystup
 * ==============
 *
 */

#include <stdio.h>

int main(void)
{
  printf("Tento program kratce pipne \007\n");
  return 0;
}

