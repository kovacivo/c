/*
 * cv01.c    v.2.0
 *
 * Tisk komplikovaneho retezce
 * ===========================
 *
 */

#include <stdio.h>

int main(void)
{
  printf("James Bond \\ \"Agent 007\" \\ # 150%% zaruka # /\n");
  printf("Spol. s rucenim neomezenym\n");
  return 0;
}

