/*
 * cv07b.c    v.2.0
 *
 * Definice komplikovaneho makra - makro
 * =====================================
 *
 */

/* prikaz #include <stdio.h>
   neni treba, protoze se provede v hlavnim souboru pred natazenim
   tohoto souboru */

#define cti_int(i)  (scanf("%d", &i), i)

