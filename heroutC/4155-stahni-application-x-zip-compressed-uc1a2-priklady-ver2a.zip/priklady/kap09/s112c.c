/*
 * s112c.c    v.2.0
 *
 * Procedura bez parametru
 * =======================
 */

#include <stdio.h>

void ahoj(void)
{
  printf("ahoj\n");
}

int main()
{
  ahoj();
  return 0;
}

