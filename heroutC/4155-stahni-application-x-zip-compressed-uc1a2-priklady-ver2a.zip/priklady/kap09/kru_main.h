/*
 * kru_main.h    ver. 2.0
 *
 * Hlavickovy soubor pro modul kru_main.c
 * ======================================
 *
 * P. Herout,  rijen 2003
 *
 */

/* podmineny preklad proti opakovanemu inkludovani */
#ifndef KRU_MAIN_H
#define KRU_MAIN_H

/* definice symbolickych konstant vyuzivanych i v jinych
   modulech */
  /* v tomto modulu zadne nejsou */

/* definice maker s parametry */
  /* v tomto modulu zadne nejsou */

/* definice globalnich typu */
  /* v tomto modulu zadne nejsou */

/* deklarace globalnich promennych modulu kru_main.c */
extern double obvod;

/* uplne funkcni prototypy globalnich funkci modulu kru_main.c */
extern double vyp_prumeru(double polomer);

#endif


