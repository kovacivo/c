/*
 * s32.c    v.2.0
 *
 * Prvni program
 * =============
 */

#include <stdio.h>

int main()                          /* bez stredniku */
{
  int i, j;

  i = 5;
  j = -1;
  j = j + 2 * i;
  return 0;
}
