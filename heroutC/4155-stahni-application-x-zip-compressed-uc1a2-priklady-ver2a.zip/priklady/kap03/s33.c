/*
 * s33.c    v.2.0
 *
 * Prvni program - verze s inicializacemi
 * ======================================
 */

#include <stdio.h>

int main()
{
  int i = 5,
      j = -1;

  j = j + 2 * i;
  return 0;
}
