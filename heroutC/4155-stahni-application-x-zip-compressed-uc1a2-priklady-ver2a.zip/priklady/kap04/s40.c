/*
 * s40.c    v.2.0
 *
 * Cteni a tisk znaku
 * ==================
 */

#include <stdio.h>

int main()
{
  int c;

  c = getchar();
  putchar(c);
  putchar('\n');
  return 0;
}
