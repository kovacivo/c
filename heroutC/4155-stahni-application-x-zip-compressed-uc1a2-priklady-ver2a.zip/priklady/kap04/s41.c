/*
 * s1.c    v.2.0
 *
 * Cteni a tisk cisla
 * ==================
 */

#include <stdio.h>

int main()
{
  int i, j;

  scanf("%d", &i);
  scanf("%d", &j);

  printf("%d%d", j, i);
  printf("%d je soucet", i + j);
  return 0;
}
