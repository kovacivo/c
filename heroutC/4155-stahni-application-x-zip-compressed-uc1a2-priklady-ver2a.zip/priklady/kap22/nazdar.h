/*
 * nazdar.h
 */

extern int n;

void nazdar(int n);
