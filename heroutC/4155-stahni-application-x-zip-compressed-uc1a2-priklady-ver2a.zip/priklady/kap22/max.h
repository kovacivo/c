/*
 * max.h
 */

#define MAX 3

#define AHOJ   "ah"
#define NAZDAR "na"
#define CAO    "ca"
