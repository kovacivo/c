/*
 * cao.h
 */

extern int c;

void cao(int c);
