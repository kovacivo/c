int main(void)
{
  i = 5;
}