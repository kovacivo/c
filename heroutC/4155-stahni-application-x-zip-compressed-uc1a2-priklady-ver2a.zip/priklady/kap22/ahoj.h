/*
 * ahoj.h
 */

extern int a;

void ahoj(int n);
