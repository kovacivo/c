/*
 * s93.c    v.2.0
 *
 * Nespravne pouziti symbolicke konstanty
 * ======================================
 */

#include <stdio.h>

#define JMENO  Katka

int main()
{
  printf("Jmenuji se JMENO\n");
  return 0;
}
